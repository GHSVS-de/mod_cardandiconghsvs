<?php
defined('_JEXEC') or die;
/*
From Dispatcher:
$module   Object,
$app,
$input,
$params Registry,
$template,
$modId String,
$moduleclass_sfx String,
$module->title Lang strings translated,
$helper
$wa
$items
*/

$class= 'container-fluid ' . $module->module . ' entwicklungs ' . $modId ;

$titel = [];

$titel_normal_1 = $params->get('titel_normal_1', '');
$titel_fett_1 = $params->get('titel_fett_1', '');
$titel_normal_2 = $params->get('titel_normal_2', '');
$titel_fett_2 = $params->get('titel_fett_2', '');



$einleitung = $params->get('einleitung', '');

$items = [];

$getThis = [
	'punkt',
	'icon',
	'text',
];

for ($i = 1; $i <= 4; $i++)
{
	$items[$i] = new stdClass();

	foreach ($getThis as $key)
	{
		$items[$i]->{$key} = $params->get($key . '_' . $i, '');
	}
}
echo ' 4654sd48sa7dddddddddddddddddd <pre>' . print_r($items, true) . '</pre>';exit;
?>

<div id="<?php echo $modId; ?>" class="<?php echo $class;?>">
	<?php if ($module->showtitle)
	{
		echo '<h1 class=moduleHeadline>' . $module->title . '</h1>';
	}?>

</div>




     <div data-vc-full-width="true" data-vc-full-width-init="true" class="vc_row wpb_row vc_row-fluid way-to-get vc_custom_1474436716674 vc_row-has-fill" style="position: relative; box-sizing: border-box;padding-top: 50px;">

                                <div class="container">

                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="ult-animation  ult-animate-viewport  ult-no-mobile " data-animate="No Animation" data-animation-delay="0" data-animation-duration="0.5" data-animation-iteration="1" style="" data-opacity_start_effect="">
                                                    <h2 style="font-size: 60px;color: #ffffff;text-align: center;margin-top:30px;" class="vc_custom_heading vc_custom_1474369416001"><span><?php echo $params->get('titel_normal_1'); ?> </span> <?php echo $params->get('titel_fett_1'); ?> <span><?php echo $params->get('titel_normal_2'); ?></span> <?php echo $params->get('titel_fett_2'); ?></h2>
                                                    <p style="font-size: 36px;color: #fff;line-height: 56px;text-align: center" class="vc_custom_heading"><?php echo $params->get('titel_feinleitungett_2'); ?></p>
                                                </div>
                                                <div class="ult-animation  ult-animate-viewport  ult-no-mobile " data-animate="No Animation" data-animation-delay="0.3" data-animation-duration="0.5" data-animation-iteration="1" style="" data-opacity_start_effect="">
                                                    <div class="vc_row wpb_row vc_inner vc_custom_1474795389342">
                                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-md-3">
                                                            <div class="vc_column-inner vc_custom_1473606584306">
                                                                <div class="wpb_wrapper">
                                                                    <div class="aio-icon-component   rapair-cases style_1">
                                                                        <div id="Info-box-wrap-8147" class="aio-icon-box default-icon" style="">
                                                                            <div class="aio-icon-default">
                                                                                <div class="ult-just-icon-wrapper  ">
                                                                                    <div class="align-icon" style="text-align:center;">
                                                                                        <div class="aio-icon none " style="color:#333;font-size:14px;display:inline-block;"> <i class="fas <?php echo $params->get('icon_1'); ?>"></i></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="aio-icon-header">
                                                                                <h3 class="aio-icon-title ult-responsive" data-ultimate-target="#Info-box-wrap-8147 .aio-icon-title" data-responsive-json-new="{'font-size':'desktop:80px;','line-height':''}" style="">1</h3></div>
                                                                        </div>
                                                                    </div>
                                                                    <h3 style="font-size: 26px;color: #ffffff;line-height: 32px;text-align: center" class="vc_custom_heading"><?php echo $params->get('punkt_1'); ?></h3>
                                                                    <div class="wpb_text_column wpb_content_element ">
                                                                        <div class="wpb_wrapper">
                                                                            <p style="text-align: center;"><span style="color: #ffffff;"><?php echo $params->get('text_1'); ?></span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-md-3">
                                                            <div class="vc_column-inner ">
                                                                <div class="wpb_wrapper">
                                                                    <div class="aio-icon-component   rapair-cases style_1">
                                                                        <div id="Info-box-wrap-6450" class="aio-icon-box default-icon" style="">
                                                                            <div class="aio-icon-default">
                                                                                <div class="ult-just-icon-wrapper  ">
                                                                                    <div class="align-icon" style="text-align:center;">
                                                                                        <div class="aio-icon none " style="color:#333;font-size:14px;display:inline-block;"> <i class="fas <?php echo $params->get('icon_2'); ?>"></i></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="aio-icon-header">
                                                                                <h3 class="aio-icon-title ult-responsive" data-ultimate-target="#Info-box-wrap-6450 .aio-icon-title" data-responsive-json-new="{'font-size':'desktop:80px;','line-height':''}" style="">2</h3></div>
                                                                        </div>
                                                                    </div>
                                                                    <h3 style="font-size: 26px;color: #ffffff;line-height: 32px;text-align: center" class="vc_custom_heading"><?php echo $params->get('punkt_2'); ?></h3>
                                                                    <div class="wpb_text_column wpb_content_element ">
                                                                        <div class="wpb_wrapper">
                                                                            <p style="text-align: center;"><span style="color: #ffffff;"><?php echo $params->get('text_2'); ?></span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-md-3">
                                                            <div class="vc_column-inner ">
                                                                <div class="wpb_wrapper">
                                                                    <div class="aio-icon-component   rapair-cases style_1">
                                                                        <div id="Info-box-wrap-6845" class="aio-icon-box default-icon" style="">
                                                                            <div class="aio-icon-default">
                                                                                <div class="ult-just-icon-wrapper  ">
                                                                                    <div class="align-icon" style="text-align:center;">
                                                                                        <div class="aio-icon none " style="color:#333;font-size:14px;display:inline-block;"> <i class="fas <?php echo $params->get('icon_3'); ?>"></i></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="aio-icon-header">
                                                                                <h3 class="aio-icon-title ult-responsive" data-ultimate-target="#Info-box-wrap-6845 .aio-icon-title" data-responsive-json-new="{'font-size':'desktop:80px;','line-height':''}" style="">3</h3></div>
                                                                        </div>
                                                                    </div>
                                                                    <h3 style="font-size: 26px;color: #ffffff;line-height: 32px;text-align: center" class="vc_custom_heading"><?php echo $params->get('punkt_3'); ?></h3>
                                                                    <div class="wpb_text_column wpb_content_element ">
                                                                        <div class="wpb_wrapper">
                                                                            <p style="text-align: center;"><span style="color: #ffffff;"><?php echo $params->get('text_3'); ?></span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-md-3">
                                                            <div class="vc_column-inner ">
                                                                <div class="wpb_wrapper">
                                                                    <div class="aio-icon-component   rapair-cases style_1">
                                                                        <div id="Info-box-wrap-6442" class="aio-icon-box default-icon" style="">
                                                                            <div class="aio-icon-default">
                                                                                <div class="ult-just-icon-wrapper  ">
                                                                                    <div class="align-icon" style="text-align:center;">
                                                                                        <div class="aio-icon none " style="color:#333;font-size:14px;display:inline-block;"> <i class="fas <?php echo $params->get('icon_4'); ?>"></i></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="aio-icon-header">
                                                                                <h3 class="aio-icon-title ult-responsive" data-ultimate-target="#Info-box-wrap-6442 .aio-icon-title" data-responsive-json-new="{'font-size':'desktop:80px;','line-height':''}" style="">4</h3></div>
                                                                        </div>
                                                                    </div>
                                                                    <h3 style="font-size: 26px;color: #ffffff;line-height: 32px;text-align: center" class="vc_custom_heading"><?php echo $params->get('punkt_4'); ?></h3>
                                                                    <div class="wpb_text_column wpb_content_element ">
                                                                        <div class="wpb_wrapper">
                                                                            <p style="text-align: center;"><span style="color: #ffffff;"><?php echo $params->get('text_4'); ?></span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="vc_row-full-width vc_clearfix"></div>
